-- Query 1
EXPLAIN ANALYZE
SELECT e.employee_id, e.first_name, e.last_name, j.job_title
FROM employees e
JOIN jobs j ON e.job_id = j.job_id;

-- Query 2
EXPLAIN ANALYZE
SELECT COUNT(e.employee_id) AS employees, j.job_title
FROM employees e
JOIN jobs j ON e.job_id = j.job_id
GROUP BY j.job_title;

-- Query 3
EXPLAIN ANALYZE
SELECT *
FROM employees e
WHERE e.salary >= 10000;

-- Query 4
EXPLAIN ANALYZE
SELECT COUNT(e.employee_id) AS total_employees, j.job_title
FROM employees e
JOIN jobs j ON e.job_id = j.job_id
GROUP BY j.job_title
HAVING COUNT(e.employee_id) > 1;
